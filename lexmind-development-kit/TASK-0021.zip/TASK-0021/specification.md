# TASK-0021 – Import Pipeline

## Goal
Implement the document import pipeline.

## Responsibilities
- Import files/folders
- Detect supported formats
- Compute checksum
- Create Document entity
- Store original file via StorageManager
- Register metadata
- Publish events

## Flow
CLI/API -> ImportService -> StorageManager -> MetadataRepository -> EventBus

## Supported
PDF, DOCX, ODT, TXT, JPG, PNG, TIFF
