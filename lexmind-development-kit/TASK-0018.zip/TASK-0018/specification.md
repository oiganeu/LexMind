# TASK-0018 – Workspace Repository

## Goal
Implement the repository responsible for persisting and retrieving Workspace domain entities.

## Responsibilities
- CRUD operations
- Lookup by UUID/name
- Pagination
- Soft delete support
- No business logic

## Interface
- create()
- update()
- get_by_id()
- get_by_uuid()
- get_by_name()
- list()
- delete()

Repositories must return Domain Workspace entities only.
