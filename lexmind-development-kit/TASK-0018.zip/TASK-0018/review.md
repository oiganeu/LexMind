Verify repository pattern, no ORM leakage, transaction safety.
