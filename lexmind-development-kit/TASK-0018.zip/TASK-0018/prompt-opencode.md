Implement the WorkspaceRepository interface and SQLite implementation using the metadata subsystem. Keep domain independent.
