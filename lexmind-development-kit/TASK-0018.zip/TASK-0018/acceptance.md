Ruff clean, MyPy clean, tests passing, >95% coverage.
