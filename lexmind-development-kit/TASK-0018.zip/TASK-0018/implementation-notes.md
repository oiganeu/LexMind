Inject SessionManager; do not create sessions inside domain.
