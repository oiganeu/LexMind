# TASK-0019 – Artifact Repository

## Goal
Implement the repository responsible for persisting Artifact domain entities.

## Responsibilities
- CRUD operations
- Associate artifacts with documents
- Versioning support
- Lookup by URI and type
- No business logic

## Interface
create()
update()
get_by_id()
get_by_uri()
list_by_document()
list_by_type()
latest_version()
delete()
