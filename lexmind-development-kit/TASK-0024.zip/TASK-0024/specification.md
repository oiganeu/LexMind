# TASK-0024 – Tesseract OCR Provider

## Goal
Implement the first OCRProvider based on Tesseract.

## Responsibilities
- Wrap Tesseract behind OCRProvider
- Accept image/PDF page input
- Return normalized OCRResult
- Support language selection
- Configurable PSM/OEM
- Report confidence when available

## Components
- TesseractOCRProvider
- TesseractConfig
- OCRResultMapper

## Constraints
- No direct use outside provider
- No business logic
- No storage access
