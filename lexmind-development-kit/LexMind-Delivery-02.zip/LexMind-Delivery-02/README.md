# LexMind Delivery 02
Planning package.
