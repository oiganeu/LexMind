# TASK-0023 – OCR Pipeline Orchestrator

## Goal
Implement an orchestrator responsible for coordinating the OCR pipeline.

## Responsibilities
- Select OCR provider
- Prepare input artifacts
- Execute OCR job
- Persist OCR output
- Publish pipeline events
- Support future OCR plugins

## Components
- OCRPipeline
- OCRDispatcher
- OCRProvider (interface)
- OCRResult
- OCRArtifactWriter

## Events
OCRStarted
OCRCompleted
OCRFailed
