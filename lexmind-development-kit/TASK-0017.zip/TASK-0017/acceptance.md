# Definition of Done
- Ruff clean
- MyPy clean
- Unit tests pass
