Use SQLAlchemy 2.x and context-managed sessions.
