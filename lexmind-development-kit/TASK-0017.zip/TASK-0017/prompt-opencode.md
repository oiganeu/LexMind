Implement TASK-0017 exactly as specified.
Keep SQLAlchemy out of the domain layer.
Repositories must return domain entities only.
