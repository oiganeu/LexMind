# Tests
- DB init
- CRUD
- Rollback
- Concurrent sessions
- Schema validation
