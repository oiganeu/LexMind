# Review Checklist
- No raw sqlite3
- No SQL outside repositories
- Dependency injection
