# TASK-0017 – SQLite Metadata Store

## Goal
Implement a persistent metadata subsystem using SQLite and SQLAlchemy 2.x.

## Scope
- Metadata only (no binary files)
- Repository pattern
- Session manager
- Migration framework
- Domain isolation

## Deliverables
- metadata/database.py
- metadata/session.py
- metadata/repositories.py
- metadata/models.py
- metadata/migrations.py
- metadata/schema.py
- metadata/exceptions.py

## Acceptance
- SQLite initializes
- CRUD repositories
- Transactions
- Tests >95%
