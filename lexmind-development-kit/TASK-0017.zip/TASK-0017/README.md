# TASK-0017 Package

SQLite Metadata Store design package.
